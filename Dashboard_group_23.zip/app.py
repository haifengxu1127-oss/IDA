
"""
IDA HERA-Style Dashboard — Standalone

- Uses ONLY ./data/Final_dataset_group_23.csv (plus optional logistics_delay.csv).
- Meets assignment visuals: stacked bar/area with abs/% + checklist, slogan, failure frequency (stacked), failure rate trend, data table.
- HERA-like layout: navbar + weather strip + 3 columns.
"""
from pathlib import Path
import numpy as np, pandas as pd, re, socket
from dash import Dash, dcc, html, Input, Output, dash_table, callback
import dash_bootstrap_components as dbc
import plotly.express as px

def free_port():
    s = socket.socket(); s.bind(('',0)); port = s.getsockname()[1]; s.close(); return port

def load_dataset():
    p = Path(__file__).parent / "data" / "Final_dataset_group_23.csv"
    if not p.exists():
        raise FileNotFoundError("Final_dataset_group_23.csv missing in ./data/")
    df = pd.read_csv(p)

    # date
    date = None
    for c in ["transmission_production_date", "vehicle_production_date"]:
        if c in df.columns:
            date = pd.to_datetime(df[c], errors="coerce"); break
    if date is None:
        date = pd.to_datetime("2000-01-01") + pd.to_timedelta(range(len(df)), unit="D")
    df["date"] = date

    # company rule (adjust if needed)
    def infer_company(s):
        s = str(s)
        if s.startswith("11-"): return "205"
        if s.startswith("12-"): return "Competitor"
        return "Unknown"
    df["company"] = df["vehicle_id"].map(infer_company) if "vehicle_id" in df.columns else "205"

    # part
    df["part"] = df["transmission_id"].astype(str) if "transmission_id" in df.columns else "UNKNOWN"

    # units + failures
    df["units_sold"] = 1
    df["failures"] = pd.to_numeric(df.get("transmission_defective_flag", 0), errors="coerce").fillna(0).clip(lower=0)

    return df

def opts(seq): return [{"label": str(x), "value": x} for x in seq]

def part_number_stub(part_id: str) -> str:
    m = re.search(r"(\\d+)", str(part_id)); return m.group(1) if m else str(part_id)

df = load_dataset()
companies = sorted(df["company"].dropna().unique().tolist())
parts_all = sorted(df["part"].dropna().unique().tolist())[:200]
date_min = pd.to_datetime(df["date"]).min()
date_max = pd.to_datetime(df["date"]).max()

app = Dash(__name__, external_stylesheets=[dbc.themes.FLATLY], title="IDA HERA-Style Dashboard")

navbar = html.Div([
    html.Img(src="/assets/logo.png", className="logo"),
    html.Span("IDA Dashboard", className="title"),
    html.A("Overview", href="#"), html.A("Quality", href="#"),
    html.A("Competition", href="#"), html.A("Help", href="#"),
    html.Div(style={"marginLeft":"auto"})
], className="navbar")

strip = html.Div([
    html.Div(["Light-blue corporate theme • Source Sans Pro • Logo"], className="small"),
    html.Div("UTC: "+pd.Timestamp.utcnow().strftime("%d %b %H:%M UTC"), style={"marginLeft":"auto"})
], className="top-strip")

layout_cols = dbc.Row([
    dbc.Col([
        html.Div(className="card", children=[
            html.Div("Controls", className="card-header"),
            html.Div(className="card-body", children=[
                dcc.Checklist(id="companies", options=opts(companies), value=companies, inline=True),
                html.Div(style={"height":"6px"}),
                dcc.Dropdown(id="parts", options=opts(parts_all), value=parts_all[:8], multi=True, placeholder="Select parts"),
                html.Div(style={"height":"6px"}),
                dcc.RadioItems(id="mode", value="pct", inline=True,
                               options=[{"label":"Percent","value":"pct"},{"label":"Absolute","value":"abs"}]),
                html.Div(style={"height":"6px"}),
                dcc.DatePickerRange(id="dates", start_date=str(date_min.date()), end_date=str(date_max.date())),
            ])
        ]),
        html.Div(className="card", children=[
            html.Div("Market Share — Stacked BAR", className="card-header"),
            html.Div(className="card-body", children=[dcc.Graph(id="fig-bar")])
        ]),
        html.Div(className="card", children=[
            html.Div("Market Share — Stacked AREA", className="card-header"),
            html.Div(className="card-body", children=[dcc.Graph(id="fig-area"),
                                                     html.Div(id="slogan", style={"fontWeight":700,"fontSize":"16px","marginTop":"8px"})])
        ]),
    ], md=4),

    dbc.Col([
        html.Div(className="card", children=[
            html.Div("Failure Rate Trend — 205 vs Competitor", className="card-header"),
            html.Div(className="card-body", children=[dcc.Graph(id="fig-rate")])
        ]),
        html.Div(className="card", children=[
            html.Div("KPIs", className="card-header"),
            html.Div(className="card-body", children=[
                html.Div([
                    html.Div(["Unique parts", html.Div(len(parts_all), className="badgePill")]),
                    html.Div(["Companies", html.Div(len(companies), className="badgePill")]),
                    html.Div(["Obs. Period", html.Div(f"{date_min.date()} → {date_max.date()}", className="badgePill")]),
                ], style={"display":"grid","gridTemplateColumns":"1fr 1fr 1fr","gap":"8px"}),
                html.Div("Tip: adjust the date range to focus on a specific campaign or model year.", className="small", style={"marginTop":"6px"})
            ])
        ]),
    ], md=4),

    dbc.Col([
        html.Div(className="card", children=[
            html.Div("Failure Frequency by Part (Stacked by Company)", className="card-header"),
            html.Div(className="card-body", children=[dcc.Graph(id="fig-fails")])
        ]),
        html.Div(className="card", children=[
            html.Div("Underlying Dataset (selected)", className="card-header"),
            html.Div(className="card-body", children=[
                dash_table.DataTable(id="tbl", page_size=10, sort_action="native", filter_action="native",
                                     style_table={"overflowX":"auto"}, style_cell={"padding":"6px"})
            ])
        ]),
    ], md=4),
])

app.layout = dbc.Container([navbar, strip, layout_cols], fluid=True)

@callback(
    Output("fig-bar","figure"),
    Output("fig-area","figure"),
    Output("slogan","children"),
    Output("fig-fails","figure"),
    Output("fig-rate","figure"),
    Output("tbl","data"),
    Output("tbl","columns"),
    Input("companies","value"),
    Input("parts","value"),
    Input("mode","value"),
    Input("dates","start_date"),
    Input("dates","end_date"),
)
def refresh(companies_sel, parts_sel, mode, start_date, end_date):
    dff = df.copy()
    if companies_sel: dff = dff[dff["company"].isin(companies_sel)]
    if parts_sel: dff = dff[dff["part"].isin(parts_sel)]
    if start_date and end_date:
        dff = dff[(pd.to_datetime(dff["date"]) >= pd.to_datetime(start_date)) &
                  (pd.to_datetime(dff["date"]) <= pd.to_datetime(end_date))]

    # Market share
    g = dff.groupby(["date","company"], as_index=False)["units_sold"].sum()
    if mode == "pct":
        g["total"] = g.groupby("date")["units_sold"].transform("sum")
        g["value"] = np.where(g["total"]>0, g["units_sold"]/g["total"]*100, 0.0)
        ylab = "Market share (%)"
    else:
        g["value"] = g["units_sold"]; ylab = "Units"

    fig_bar = px.bar(g, x="date", y="value", color="company", barmode="stack",
                     labels={"value": ylab, "date":"Date", "company":"Company"})
    fig_area = px.area(g, x="date", y="value", color="company",
                       labels={"value": ylab, "date":"Date", "company":"Company"})

    # Slogan
    if parts_sel:
        stubs = sorted({part_number_stub(p) for p in parts_sel})
        x_text = " / ".join(stubs[:4]) + (" …" if len(stubs) > 4 else "")
    else:
        x_text = "x"
    slogan = f"there is a part of 202 in every {x_text} gearbox"

    # Failure frequency
    g2 = dff.groupby(["part","company"], as_index=False)["failures"].sum()
    g2["total_fail"] = g2.groupby("part")["failures"].transform("sum")
    top_parts = g2.groupby("part")["total_fail"].max().sort_values(ascending=False).head(20).index
    g2 = g2[g2["part"].isin(top_parts)]
    fig_fails = px.bar(g2, x="part", y="failures", color="company", barmode="stack",
                       labels={"failures":"Failure count", "part":"Part", "company":"Company"})

    # Failure rate trend
    d3 = dff.groupby(["date","company"], as_index=False).agg(failures=("failures","sum"),
                                                             units=("units_sold","sum"))
    d3["failure_rate"] = np.where(d3["units"]>0, d3["failures"]/d3["units"], np.nan)
    fig_rate = px.line(d3, x="date", y="failure_rate", color="company",
                       labels={"failure_rate":"Failure rate", "date":"Date", "company":"Company"})

    # Table
    cols_keep = ["date","company","part","units_sold","failures"]
    data = dff[cols_keep].sort_values("date", ascending=False).head(2000).to_dict("records")
    cols = [{"name": c, "id": c} for c in cols_keep]

    return fig_bar, fig_area, slogan, fig_fails, fig_rate, data, cols

if __name__ == "__main__":
    port = free_port()
    print(f"Open http://127.0.0.1:{port}")
    app.run_server(debug=False, port=port, use_reloader=False)
